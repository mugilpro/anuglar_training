//initial
// import { Component } from "@angular/core";

// @Component({
//  selector: "first",
//  template: `<div class="bg-primary text-white p-2">First Component</div>`
// })

// export class FirstComponent { }








// Listing 29-8. Adding a Service Dependency in the first.component.ts File in the src/app/ondemand Folder

// import { Component } from "@angular/core";
// import { Product } from "../model/product.model";
// import { Model } from "../model/repository.model";

// @Component({
//  selector: "first",
//  template: `<div class="bg-primary p-a-1">
//  There are
//  <span class="strong"> {{getProducts().length}} </span>
//  products
//  </div>`
// })

// export class FirstComponent {
//  constructor(private repository: Model) {}
//  category: string = "Soccer";
//  getProducts(): Product[] {
//  return this.repository.getProducts()
//  .filter(p => p.category == this.category);
//  }
// }






// Listing 29-11. Specifying a External Template in the first.component.ts File in the src/app/ondemand Folder
// import { Component } from "@angular/core";
// import { Product } from "../model/product.model";
// import { Model } from "../model/repository.model";
// @Component({
//  selector: "first",
//  templateUrl: "first.component.html"
// })
// export class FirstComponent {
//  constructor(private repository: Model) {}
//  category: string = "Soccer";
//  getProducts(): Product[] {
//  return this.repository.getProducts()
//  .filter(p => p.category == this.category);
//  }
// }






// Listing 29-14. Adding Event Handling in the first.component.ts File in the src/app/ondemand Folder

// import { Component, HostListener} from "@angular/core";
// import { Product } from "../model/product.model";
// import { Model } from "../model/repository.model";

// @Component({
//  selector: "first",
//  templateUrl: "first.component.html"
// })

// export class FirstComponent {
//  constructor(private repository: Model) {}
//  category: string = "Soccer";
//  highlighted: boolean = false;
//  getProducts(): Product[] {
//  return this.repository.getProducts()
//  .filter(p => p.category == this.category);
//  }
//  @HostListener("mouseenter", ["$event.type"])
//  @HostListener("mouseleave", ["$event.type"])
//  setHighlight(type: string) {
//  this.highlighted = type == "mouseenter";
//  }
// }


// The setHighlight method has configured so that it will be invoked when the host element’s
// mouseenter and mouseleave events are triggered. Listing 29-15 updates the component’s template so that it
// uses the new property in a data binding.








// Listing 29-17. Adding an Output Property in the first.component.ts File in the src/app/ondemand Folder
// import { Component, HostListener, Output, EventEmitter} from "@angular/core";
// import { Product } from "../model/product.model";
// import { Model } from "../model/repository.model";
// @Component({
//  selector: "first",
//  templateUrl: "first.component.html"
// })
// export class FirstComponent {
//  constructor(private repository: Model) {}
//  category: string = "Soccer";
//  highlighted: boolean = false;
//  @Output("pa-highlight")
//  change = new EventEmitter<boolean>();
//  getProducts(): Product[] {
//  return this.repository.getProducts()
//  .filter(p => p.category == this.category);
//  }
//  @HostListener("mouseenter", ["$event.type"])
//  @HostListener("mouseleave", ["$event.type"])
//  setHighlight(type: string) {
//  this.highlighted = type == "mouseenter";
//  this.change.emit(this.highlighted);
//  }
// }

// The component defines an output property called change, which is used to emit an event when the
// setHighlight method is called. Listing 29-18 shows a unit test that targets the output property





// Listing 29-19. Adding an Input Property in the first.component.ts File in the src/app/ondemand Folder
import { Component, HostListener, Input } from "@angular/core";
import { Product } from "../model/product.model";
import { Model } from "../model/repository.model";
@Component({
 selector: "first",
 templateUrl: "first.component.html"
})
export class FirstComponent {
 category: string = "Soccer";
 highlighted: boolean = false;
 getProducts(): Product[] {
 return this.model == null ? [] : this.model.getProducts()
 .filter(p => p.category == this.category);
 }
 @Input("pa-model")
 model: Model;
}

// The input property is set using an attribute called pa-model and is used within the getProducts
// method. Listing 29-20 shows how to write a unit test that targets the input property.





























//final
// import { Component, HostListener, Input } from "@angular/core";
// import { Product } from "../model/product.model";
// import { Model } from "../model/repository.model";
// import { RestDataSource } from "../model/rest.datasource";

// @Component({
//     selector: "first",
//     templateUrl: "first.component.html"
// })
// export class FirstComponent {
//     _category: string = "Soccer";
//     _products: Product[] = [];
//     highlighted: boolean = false;

//     constructor(public datasource: RestDataSource) {}

//     ngOnInit() {
//         this.updateData();
//     }

//     getProducts(): Product[] {
//         return this._products;
//     }

//     set category(newValue: string) {
//         this._category;
//         this.updateData();
//     }

//     updateData() {
//         this.datasource.getData()
//             .subscribe(data => this._products = data
//                 .filter(p => p.category == this._category));
//     }
// }
