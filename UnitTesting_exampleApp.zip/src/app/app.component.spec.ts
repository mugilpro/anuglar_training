
// Listing 29-3. Replacing the Contents of the app.component.spec.ts File in the src/app Folder
// describe("Jasmine Test Environment", () => {
//  it("is working", () => expect(true).toBe(true));
// });




// Listing 29-4. Making a Unit Test Fail in the app.component.spec.ts File in the src/app Folder
// describe("Jasmine Test Environment", () => {
//  it("is working", () => expect(true).toBe(false));
// });



// Listing 29-5. Replacing the Unit Test in the app.component.spec.ts File in the src/app Folder
// describe("Jasmine Test Environment", () => {
//  it("test numeric value", () => expect(12).toBeGreaterThan(10));
//  it("test string value", () => expect("London").toMatch("^Lon"));
// });










//other
// describe("Jasmine Test Environment", () => {
//   it("test numeric value", () => expect(12).toBeGreaterThan(10));
//   it("test string value", () => expect("London").toMatch("^Lon"));
// });
