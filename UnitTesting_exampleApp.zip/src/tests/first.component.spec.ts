
// Listing 29-6. The Contents of the first.component.spec.ts File in the src/tests Folder
// import { TestBed } from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";

// describe("FirstComponent", () => {
//  beforeEach(() => {

//  TestBed.configureTestingModule({
//  declarations: [FirstComponent]
//  });
//  });
// });





// Listing 29-7. Creating a Component in the first.component.spec.ts File in the src/tests Folder
// import { TestBed, ComponentFixture} from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";

// describe("FirstComponent", () => {
//  let fixture: ComponentFixture<FirstComponent>;
//  let component: FirstComponent;
//  beforeEach(() => {
//     TestBed.configureTestingModule({
//     declarations: [FirstComponent]
//     });
//     fixture = TestBed.createComponent(FirstComponent);
//     component = fixture.componentInstance;
//     });
//     it("is defined", () => {
//     expect(component).toBeDefined()
//     });
//    });





// Listing 29-9. Providing a Service in the first.component.spec.ts File in the src/tests Folder

// import { TestBed, ComponentFixture} from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";

// describe("FirstComponent", () => {
//  let fixture: ComponentFixture<FirstComponent>;
//  let component: FirstComponent;

//  let mockRepository = {
//  getProducts: function () {
//  return [
//     new Product(1, "test1", "Soccer", 100),
//     new Product(2, "test2", "Chess", 100),
//     new Product(3, "test3", "Soccer", 100),
//     ]
//     }
//     }


//     beforeEach(() => {
//     TestBed.configureTestingModule({
//     declarations: [FirstComponent],
//     providers: [
//     { provide: Model, useValue: mockRepository }
//     ]
//     });
//     fixture = TestBed.createComponent(FirstComponent);
//     component = fixture.componentInstance;
//     });



//     it("filters categories", () => {
//     component.category = "Chess"
//     expect(component.getProducts().length).toBe(1);
//     component.category = "Soccer";
//     expect(component.getProducts().length).toBe(2);
//     component.category = "Running";
//     expect(component.getProducts().length).toBe(0);
//     });
//    });








// Listing 29-10. Unit Testing a Data Binding in the first.component.spec.ts File in the src/tests Folder

// import { TestBed, ComponentFixture} from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";
// import { DebugElement } from "@angular/core";
// import { By } from "@angular/platform-browser";

// describe("FirstComponent", () => {
//     let fixture: ComponentFixture<FirstComponent>;
//     let component: FirstComponent;
//     let debugElement: DebugElement;
//     let bindingElement: HTMLSpanElement;

//     let mockRepository = {
//     getProducts: function () {
//     return [
//     new Product(1, "test1", "Soccer", 100),
//     new Product(2, "test2", "Chess", 100),
//     new Product(3, "test3", "Soccer", 100),
//     ]
//     }
//     }

//     beforeEach(() => {
//     TestBed.configureTestingModule({
//     declarations: [FirstComponent],
//     providers: [
//     { provide: Model, useValue: mockRepository }
//     ]
//     });

//     fixture = TestBed.createComponent(FirstComponent);
//     component = fixture.componentInstance;
//     debugElement = fixture.debugElement;
//     bindingElement = debugElement.query(By.css("span")).nativeElement;
//     });
//     it("filters categories", () => {
//     component.category = "Chess"
//     fixture.detectChanges();
//     expect(component.getProducts().length).toBe(1);
//     expect(bindingElement.textContent).toContain("1");
//     component.category = "Soccer";
//     fixture.detectChanges();
//     expect(component.getProducts().length).toBe(2);
//     expect(bindingElement.textContent).toContain("2");
//     component.category = "Running";
//     fixture.detectChanges();
//     expect(component.getProducts().length).toBe(0);
//     expect(bindingElement.textContent).toContain("0");
//     });
//    });

//    The ComponentFixture.debugElement property returns a DebugElement object that represents the
//    root element from the component’s template, and Table 29-7 lists the most useful methods and properties
//    described by the DebugElement class.


// fixture.detectChanges();

// This method tells the Angular testing environment to process any changes and evaluate the data
// binding expressions in the template. Without this method call, the change to the value of the category
// component would not be reflected in the template, and the test would fail.








// Listing 29-13. Compiling a Component in the first.component.spec.ts File in the src/tests Folder
// import { TestBed, ComponentFixture, async } from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";
// import { DebugElement } from "@angular/core";
// import { By } from "@angular/platform-browser";

// describe("FirstComponent", () => {
//  let fixture: ComponentFixture<FirstComponent>;
//  let component: FirstComponent;
//  let debugElement: DebugElement;
//  let spanElement: HTMLSpanElement;
//  let mockRepository = {
//  getProducts: function () {
//  return [
//  new Product(1, "test1", "Soccer", 100),
//  new Product(2, "test2", "Chess", 100),
//  new Product(3, "test3", "Soccer", 100),
//  ]
//  }
//  }

//  beforeEach(async(() => {
//  TestBed.configureTestingModule({
//  declarations: [FirstComponent],
//  providers: [
//  { provide: Model, useValue: mockRepository }
//  ]
//  });

//  TestBed.compileComponents().then(() => {
//  fixture = TestBed.createComponent(FirstComponent);
//  component = fixture.componentInstance;
//  debugElement = fixture.debugElement;
//  spanElement = debugElement.query(By.css("span")).nativeElement;
//  });
//  }));

//  it("filters categories", () => {
//  component.category = "Chess"
//  fixture.detectChanges();
//  expect(component.getProducts().length).toBe(1);
//  expect(spanElement.textContent).toContain("1");
//  });
// });


// Components are compiled using the TestBed.compileComponents method. The compilation process
// is asynchronous, and the compileComponents method returns a Promise, which must be used to complete
// the test setup when the compilation is complete. To make it easier to work with asynchronous operations
// in unit tests, the @angular/core/testing module contains a function called async, which is used with the
// beforeEach method.





// Listing 29-16. Triggering Events in the first.component.spec.ts File in the src/tests Folder
// import { TestBed, ComponentFixture, async } from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";
// import { DebugElement } from "@angular/core";
// import { By } from "@angular/platform-browser";
// describe("FirstComponent", () => {
//  let fixture: ComponentFixture<FirstComponent>;
//  let component: FirstComponent;
//  let debugElement: DebugElement;
//  let divElement: HTMLDivElement;
//  let mockRepository = {
//  getProducts: function () {
//  return [
//  new Product(1, "test1", "Soccer", 100),
//  new Product(2, "test2", "Chess", 100),
//  new Product(3, "test3", "Soccer", 100),
//  ]
//  }
//  }
//  beforeEach(async(() => {
//  TestBed.configureTestingModule({
//  declarations: [FirstComponent],
//  providers: [
//  { provide: Model, useValue: mockRepository }
//  ]
//  });
//  TestBed.compileComponents().then(() => {
//  fixture = TestBed.createComponent(FirstComponent);
//  component = fixture.componentInstance;
//  debugElement = fixture.debugElement;
//  divElement = debugElement.children[0].nativeElement;
//  });
//  }));
//  it("handles mouse events", () => {
//  expect(component.highlighted).toBeFalsy();
//  expect(divElement.classList.contains("bg-success")).toBeFalsy();
//  debugElement.triggerEventHandler("mouseenter", new Event("mouseenter"));
//  fixture.detectChanges();
//  expect(component.highlighted).toBeTruthy();
//  expect(divElement.classList.contains("bg-success")).toBeTruthy();
//  debugElement.triggerEventHandler("mouseleave", new Event("mouseleave"));

//  fixture.detectChanges();
//  expect(component.highlighted).toBeFalsy();
//  expect(divElement.classList.contains("bg-success")).toBeFalsy();
//  });
// });

// The test in this listing checks the initial state of the component and the template and then triggers the
// mouseenter and mouseleave events, checking the effect that each has.






// Listing 29-18. Testing an Output Property in the first.component.spec.ts File in the src/tests Folder
// import { TestBed, ComponentFixture, async } from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";
// import { DebugElement } from "@angular/core";
// import { By } from "@angular/platform-browser";
// describe("FirstComponent", () => {
//  let fixture: ComponentFixture<FirstComponent>;
//  let component: FirstComponent;
//  let debugElement: DebugElement;
//  let mockRepository = {
//  getProducts: function () {
//  return [
//  new Product(1, "test1", "Soccer", 100),
//  new Product(2, "test2", "Chess", 100),
//  new Product(3, "test3", "Soccer", 100),
//  ]
//  }
//  }
//  beforeEach(async(() => {
//  TestBed.configureTestingModule({
//  declarations: [FirstComponent],
//  providers: [
//  { provide: Model, useValue: mockRepository }
//  ]
//  });
//  TestBed.compileComponents().then(() => {
//  fixture = TestBed.createComponent(FirstComponent);
//  component = fixture.componentInstance;
//  debugElement = fixture.debugElement;
//  });
//  }));
//  it("implements output property", () => {
//  let highlighted: boolean;
//  component.change.subscribe(value => highlighted = value);
//  debugElement.triggerEventHandler("mouseenter", new Event("mouseenter"));
//  expect(highlighted).toBeTruthy();
//  debugElement.triggerEventHandler("mouseleave", new Event("mouseleave"));
//  expect(highlighted).toBeFalsy();
//  });
// });







// I could have invoked the component’s setHighlight method directly in the unit test, but instead I have
// chosen to trigger the mouseenter and mouseleave events, which will activate the output property indirectly.
// Before triggering the events, I use the subscribe method to receive the event from the output property,
// which is then used to check for the expected outcomes.




// Listing 29-20. Testing an Input Property in the first.component.spec.ts File in the src/tests Folder
import { TestBed, ComponentFixture, async } from "@angular/core/testing";
import { FirstComponent } from "../app/ondemand/first.component";
import { Product } from "../app/model/product.model";
import { Model } from "../app/model/repository.model";
import { DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { Component, ViewChild } from "@angular/core";

@Component({
    template: `<first [pa-model]="model"></first>`
   })
   class TestComponent {
    constructor(public model: Model) { }
    @ViewChild(FirstComponent)
    firstComponent: FirstComponent;
   }
   describe("FirstComponent", () => {
    let fixture: ComponentFixture<TestComponent>;
    let component: FirstComponent;
    let debugElement: DebugElement;
    let mockRepository = {
    getProducts: function () {
    return [
    new Product(1, "test1", "Soccer", 100),
    new Product(2, "test2", "Chess", 100),
    new Product(3, "test3", "Soccer", 100),
    ]
    }
    }
    beforeEach(async(() => {
    TestBed.configureTestingModule({
    declarations: [FirstComponent, TestComponent],
    providers: [
    { provide: Model, useValue: mockRepository }
    ]
    });
    TestBed.compileComponents().then(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance.firstComponent;
    debugElement = fixture.debugElement.query(By.directive(FirstComponent));
    });
    }));
    it("receives the model through an input property", () => {
    component.category = "Chess";
    fixture.detectChanges();
    let products = mockRepository.getProducts()
    .filter(p => p.category == component.category);
    let componentProducts = component.getProducts();
    for (let i = 0; i < componentProducts.length; i++) {
    expect(componentProducts[i]).toEqual(products[i]);
    }

    expect(debugElement.query(By.css("span")).nativeElement.textContent)
 .toContain(products.length);
 });
});

// The trick here is to define a component that is only required to set up the test and whose template
// contains an element that matches the selector of the component you want to target. In this example,
// I defined a component class called TestComponent with an inline template defined in the @Component
// decorator that contains a first element with a pa-model attribute, which corresponds to the @Input
// decorator applied to the FirstComponent class.

// The test component class is added to the declarations array for the testing module, and an
// instance is created using the TestBed.createComponent method. I used the @ViewChild decorator in the
// TestComponent class so that I can get hold of the FirstComponent instance I require for the test. To get the
// FirstComponent root element, I used the DebugElement.query method with the By.directive method.
// The result is that I am able to access both the component and its root element for the test, which sets
// the category property and then validates the results both from the component and through the data binding
// in its template











































//final
// import { TestBed, ComponentFixture, async, fakeAsync, tick } from "@angular/core/testing";
// import { FirstComponent } from "../app/ondemand/first.component";
// import { Product } from "../app/model/product.model";
// import { Model } from "../app/model/repository.model";
// import { DebugElement } from "@angular/core";
// import { By } from "@angular/platform-browser";
// import { Component, ViewChild } from "@angular/core";
// import { RestDataSource } from "../app/model/rest.datasource";
// import { Observable } from "rxjs";
// import { Injectable } from "@angular/core";

// @Injectable()
// class MockDataSource {
//     public data = [
//         new Product(1, "test1", "Soccer", 100),
//         new Product(2, "test2", "Chess", 100),
//         new Product(3, "test3", "Soccer", 100),
//     ];

//     getData(): Observable<Product[]> {
//         return new Observable<Product[]>(obs => {
//             setTimeout(() => obs.next(this.data), 1000);
//         })
//     }
// }

// describe("FirstComponent", () => {

//     let fixture: ComponentFixture<FirstComponent>;
//     let component: FirstComponent;
//     let dataSource = new MockDataSource();

//     beforeEach(async(() => {
//         TestBed.configureTestingModule({
//             declarations: [FirstComponent],
//             providers: [
//                 { provide: RestDataSource, useValue: dataSource }
//             ]
//         });
//         TestBed.compileComponents().then(() => {
//             fixture = TestBed.createComponent(FirstComponent);
//             component = fixture.componentInstance;
//         });
//     }));

//     it("performs async op", fakeAsync( () => {
//         dataSource.data.push(new Product(100, "test100", "Soccer", 100));

//         fixture.detectChanges();

//         for (let i = 0; i < 1001; i++)  {
//           tick(1);
//         }

//         fixture.whenStable().then(() => {
//             expect(component.getProducts().length).toBe(3);
//         });
//     }));
// });
